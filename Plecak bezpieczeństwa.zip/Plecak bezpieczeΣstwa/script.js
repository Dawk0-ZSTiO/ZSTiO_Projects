const uselessIds = ['garnek', 'helikopter', 'hantle', 'jajo', 'wanna'];

const items = [
  { id: '20zl', prettyName: '20 zł', isUseless: false },
  { id: 'apteczka', prettyName: 'Apteczka', isUseless: false },
  { id: 'butelka', prettyName: 'Butelka', isUseless: false },
  { id: 'dokumenty', prettyName: 'Dokumenty', isUseless: false },
  { id: 'garnek', prettyName: 'Garnek', isUseless: true },
  { id: 'hantle', prettyName: 'Hantle', isUseless: true },
  { id: 'helikopter', prettyName: 'Helikopter', isUseless: true },
  { id: 'jajo', prettyName: 'Jajo', isUseless: true },
  { id: 'jedzenie', prettyName: 'Jedzenie', isUseless: false },
  { id: 'kombinerki', prettyName: 'Kombinerki', isUseless: false },
  { id: 'kurtka', prettyName: 'Kurtka', isUseless: false },
  { id: 'latarka', prettyName: 'Latarka', isUseless: false },
  { id: 'mapa', prettyName: 'Mapa', isUseless: false },
  { id: 'maska', prettyName: 'Maska', isUseless: false },
  { id: 'mydlo', prettyName: 'Mydło', isUseless: false },
  { id: 'notatnik', prettyName: 'Notatnik', isUseless: false },
  { id: 'noz', prettyName: 'Nóż', isUseless: false },
  { id: 'olowek', prettyName: 'Ołówek', isUseless: false },
  { id: 'opaska', prettyName: 'Opaska', isUseless: false },
  { id: 'otwieracz', prettyName: 'Otwieracz', isUseless: false },
  { id: 'przewod', prettyName: 'Przewód', isUseless: false },
  { id: 'radio', prettyName: 'Radio', isUseless: false },
  { id: 'spiwor', prettyName: 'Śpiwór', isUseless: false },
  { id: 'sztucce', prettyName: 'Sztućce', isUseless: false },
  { id: 'ubrania', prettyName: 'Ubrania', isUseless: false },
  { id: 'wanna', prettyName: 'Wanna', isUseless: true },
  { id: 'worki', prettyName: 'Worki', isUseless: false },
  { id: 'zapalniczka', prettyName: 'Zapalniczka', isUseless: false }
];

items.sort(() => Math.random() - 0.5);

let packed = [];
let totalPoints = 0;
let maxPoints = items.map(i => getPoints(i)).filter(p => p > 0).reduce((a,b)=>a+b,0);
let uselessMessages = [];

function getPoints(item) {
  if (item.isUseless) return -5;

  switch (item.id) {
    case 'apteczka': return 10;
    case 'dokumenty': return 8;
    case 'jedzenie': return 7;
    case 'latarka':
    case 'mapa': return 6;
    case 'maska':
    case 'noz': return 5;
    case 'spiwor':
    case 'ubrania': return 4;
    case 'zapalniczka':
    case 'butelka': return 3;
    case 'mydlo':
    case 'worki':
    case 'radio': return 2;
    default: return 1;
  }
}

function renderItems() {
  const container = document.getElementById('itemsContainer');
  container.innerHTML = '';

  items.forEach(item => {
    const div = document.createElement('div');
    div.className = 'item';
    div.innerHTML = `
      <img src="img/${item.id}.png" alt="${item.prettyName}">
      <p>${item.prettyName}</p>
    `;
    div.onclick = () => pack(item);
    container.appendChild(div);
  });
}

function pack(item) {
  packed.push(item);
  totalPoints += getPoints(item);

  if (item.isUseless) {
    uselessMessages.push(`Po co tobie ${item.prettyName.toLowerCase()}?`);
  }

  items.splice(items.indexOf(item), 1);
  renderItems();
  renderPacked();
}

function renderPacked() {
  const tbody = document.getElementById('packedList');
  tbody.innerHTML = packed.map(i => `<tr><td>${i.prettyName}</td></tr>`).join('');
}

function getRating() {
  if (totalPoints === maxPoints) {
    return 'Plecak spakowany IDEALNIE - masz wszystko, co potrzebne!';
  } else if (totalPoints >= maxPoints * 0.7) {
    return 'Plecak spakowany całkiem dobrze - większość kluczowych rzeczy jest na miejscu.';
  } else if (totalPoints >= maxPoints * 0.4) {
    return 'Plecak spakowany średnio - brakuje kilku ważnych elementów.';
  } else {
    return 'Plecak spakowany słabo - brakuje kluczowych przedmiotów.';
  }
}

document.getElementById('checkBtn').onclick = () => {

  const resultData = {
    totalPoints,
    maxPoints,
    rating: getRating(),
    uselessMessages
  };

  localStorage.setItem("plecakResult", JSON.stringify(resultData));

  window.open("result.html", "_blank");
};

renderItems();
