const data = JSON.parse(localStorage.getItem("plecakResult"));

if (data) {
  document.getElementById("ratingText").innerText = data.rating;
  document.getElementById("pointsText").innerText = `${data.totalPoints} / ${data.maxPoints}`;

  const ul = document.getElementById("uselessList");
  ul.innerHTML = data.uselessMessages.map(m => `<li>${m}</li>`).join('');
}